package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Department
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="dept_id")
	private int deptId;
	@Column(name="dept_name")
	private String deptName;
	/*@OneToOne(mappedBy = "department")
	private VisitorDetails visitorDetails;*/
	public Department()
	{

	}
	@Override
	public String toString()
	{
		return "Department{" +
				"deptId=" + deptId +
				", deptName='" + deptName + '\'' +
				/*", visitorDetails=" + visitorDetails +*/
				'}';
	}
	public int getDeptId()
	{
		return deptId;
	}
	public void setDeptId(int deptId)
	{
		this.deptId = deptId;
	}
	public String getDeptName()
	{
		return deptName;
	}
	public void setDeptName(String deptName)
	{
		this.deptName = deptName;
	}
}
/*public VisitorDetails getVisitorDetails() {
		return visitorDetails;
	}

	public void setVisitorDetails(VisitorDetails visitorDetails) {
		this.visitorDetails = visitorDetails;
	}*/
