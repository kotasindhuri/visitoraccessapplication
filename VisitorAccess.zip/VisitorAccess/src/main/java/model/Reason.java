package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reason {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="reason_id")
    private int reasonId;
    @Column(name="reason_name")
    private String reasonName;

    /*@OneToOne(mappedBy = "reason")
    private VisitorDetails visitorDetails;*/
    public Reason()
    {

    }

    @Override
    public String toString() {
        return "Reason{" +
                "reasonId=" + reasonId +
                ", reasonName='" + reasonName + '\'' +
               /* ", visitorDetails=" + visitorDetails +*/
                '}';
    }

    public int getReasonId() {
        return reasonId;
    }

    public void setReasonId(int reasonId) {
        this.reasonId = reasonId;
    }

    public String getReasonName() {
        return reasonName;
    }

    public void setReasonName(String reasonName) {
        this.reasonName = reasonName;
    }


}
 /* public VisitorDetails getVisitorDetails() {
        return visitorDetails;
    }

    public void setVisitorDetails(VisitorDetails visitorDetails) {
        this.visitorDetails = visitorDetails;
    }
*/
