package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
@Entity
@Table(name = "visitor_details")
public class VisitorDetails
{
    @Id
    @Column(name="visitor_id")
    private int visitorId;
    @Column(name="visitor_name")
    private String visitorName;
    @Column(name="visitor_type_id")
    private String visitorTypeId;
    @Column(name="visitor_email_id")
    private String visitorEmailId;
    @Column(name="access_req_from")
    private Date accessReqFrom;
    @Column(name="access_req_till")
    private Date accessReqTill;
    @Column(name="addition_material")
    private String additionMaterial;
    @Column(name="authorized_escort")
    private String authorizedEscort;
    @Column(name="dept_id")
    private int deptId;
    @Column(name="status_id")
    private int statusId;
    @Column(name="reason_id")
    private int reasonId;
    @Column(name="location_id")
    private int locationId;
    @Column(name="approver_comments")
    private String approverComments;
    @Column(name="visitor_approval_action")
    private String visitorApprovalAction;
    @Column(name="created_by")
    private String createdBy;
    @Column(name="modified_by")
    private String modifiedBy;
    @Column(name="created_date")
    private Date createdDate;
    @Column(name="modified_date")
    private Date modifiedDate;

    /*@OneToOne(cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH},fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn (name = "reason_id")
    private Reason reason;

    @OneToOne(cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH},fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn (name = "dep_id")
    private Department department;

    @OneToOne(cascade = {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH},fetch = FetchType.LAZY)
    @PrimaryKeyJoinColumn (name = "location_id")
    private Location location;*/

    public int getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(int visitorId) {
        this.visitorId = visitorId;
    }

    public String getVisitorName() {
        return visitorName;
    }

    public void setVisitorName(String visitorName) {
        this.visitorName = visitorName;
    }

    public String getVisitorTypeId() {
        return visitorTypeId;
    }

    public void setVisitorTypeId(String visitorTypeId) {
        this.visitorTypeId = visitorTypeId;
    }

    public String getVisitorEmailId() {
        return visitorEmailId;
    }

    public void setVisitorEmailId(String visitorEmailId) {
        this.visitorEmailId = visitorEmailId;
    }

    public Date getAccessReqFrom() {
        return accessReqFrom;
    }

    public void setAccessReqFrom(Date accessReqFrom) {
        this.accessReqFrom = accessReqFrom;
    }

    public Date getAccessReqTill() {
        return accessReqTill;
    }

    public void setAccessReqTill(Date accessReqTill) {
        this.accessReqTill = accessReqTill;
    }

    public String getAdditionMaterial() {
        return additionMaterial;
    }

    public void setAdditionMaterial(String additionMaterial) {
        this.additionMaterial = additionMaterial;
    }

    public String getAuthorizedEscort() {
        return authorizedEscort;
    }

    public void setAuthorizedEscort(String authorizedEscort) {
        this.authorizedEscort = authorizedEscort;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public int getReasonId() {
        return reasonId;
    }

    public void setReasonId(int reasonId) {
        this.reasonId = reasonId;
    }

    public int getLocationId() {
        return locationId;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public String getApproverComments() {
        return approverComments;
    }

    public void setApproverComments(String approverComments) {
        this.approverComments = approverComments;
    }

    public String getVisitorApprovalAction() {
        return visitorApprovalAction;
    }

    public void setVisitorApprovalAction(String visitorApprovalAction)
    {
        this.visitorApprovalAction = visitorApprovalAction;
    }
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

   /* public Reason getReason() {
        return reason;
    }

    public void setReason(Reason reason) {
        this.reason = reason;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }*/
    public VisitorDetails() {
    }
    @Override
    public String toString() {
        return "VisitorDetails{" +
                "visitorId=" + visitorId +
                ", visitorTypeId='" + visitorTypeId + '\'' +
                ", visitorEmailId='" + visitorEmailId + '\'' +
                ", accessReqFrom=" + accessReqFrom +
                ", accessReqTill=" + accessReqTill +
                ", additionMaterial='" + additionMaterial + '\'' +
                ", authorizedEscort='" + authorizedEscort + '\'' +
                ", deptId=" + deptId +
                ", statusId=" + statusId +
                ", reasonId=" + reasonId +
                ", locationId=" + locationId +
                ", approverComments='" + approverComments + '\'' +
                ", visitorApprovalAction='" + visitorApprovalAction + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", createdDate=" + createdDate +
                ", modifiedDate=" + modifiedDate +
                ", visitorName=" + visitorName +
               /* ", reason=" + reason +
                ", department=" + department +
                ", location=" + location +*/
                '}';
    }
}