package model;
import java.util.Date;

public class VisitorInfo
{
    @Override
    public String toString()
    {
        return "VisitorDetails1 [visitorId=" + visitorId + ", visitorName=" + visitorName + ", visitorType="
                    + visitorType + ", visitorEmailId=" + visitorEmailId + ", accessReqFrom=" + accessReqFrom
                    + ", accessReqTill=" + accessReqTill + ", additionMaterial=" + additionMaterial + ", authorizedEscort="
                    + authorizedEscort + ", deptName=" + deptName + ", locationName=" + locationName + ", reasonName="
                    + reasonName + ", approverComments=" + approverComments + ", visitorApprovalAction="
                    + visitorApprovalAction + ", createdDate=" + createdDate + ", modifiedDate=" + modifiedDate
                    + ", statusName=" + statusName + ", modifiedBy=" + modifiedBy + "]";
    }
        private int visitorId;
        private String visitorName;
        private String visitorType;
        private String visitorEmailId;
        private Date accessReqFrom;
        private Date accessReqTill;
        private String additionMaterial;
        private String authorizedEscort;
        private String deptName;
        private String locationName;
        private String reasonName;
        private String approverComments;
        private String visitorApprovalAction;
        private Date createdDate;
        private Date modifiedDate;
        private String statusName;
        private String modifiedBy;
        public int getVisitorId() {
            return visitorId;
        }
        public void setVisitorId(int visitorId) {
            this.visitorId = visitorId;
        }
        public String getVisitorName() {
            return visitorName;
        }
        public void setVisitorName(String visitorName) {
            this.visitorName = visitorName;
        }
        public String getVisitorType() {
            return visitorType;
        }
        public void setVisitorType(String visitorType) {
            this.visitorType = visitorType;
        }
        public String getVisitorEmailId() {
            return visitorEmailId;
        }
        public void setVisitorEmailId(String visitorEmailId) {
            this.visitorEmailId = visitorEmailId;
        }
        public Date getAccessReqFrom() {
            return accessReqFrom;
        }
        public void setAccessReqFrom(Date accessReqFrom) {
            this.accessReqFrom = accessReqFrom;
        }
        public Date getAccessReqTill() {
            return accessReqTill;
        }
        public void setAccessReqTill(Date accessReqTill) {
            this.accessReqTill = accessReqTill;
        }
        public String getAdditionMaterial() {
            return additionMaterial;
        }
        public void setAdditionMaterial(String additionMaterial) {
            this.additionMaterial = additionMaterial;
        }
        public String getAuthorizedEscort() {
            return authorizedEscort;
        }
        public void setAuthorizedEscort(String authorizedEscort) {
            this.authorizedEscort = authorizedEscort;
        }
        public String getDeptName() {
            return deptName;
        }
        public void setDeptName(String deptName) {
            this.deptName = deptName;
        }
        public String getLocationName() {
            return locationName;
        }
        public void setLocationName(String locationName) {
            this.locationName = locationName;
        }
        public String getReasonName() {
            return reasonName;
        }
        public void setReasonName(String reasonName) {
            this.reasonName = reasonName;
        }
        public String getApproverComments() {
            return approverComments;
        }
        public void setApproverComments(String approverComments) {
            this.approverComments = approverComments;
        }
        public String getVisitorApprovalAction() {
            return visitorApprovalAction;
        }
        public void setVisitorApprovalAction(String visitorApprovalAction) {
            this.visitorApprovalAction = visitorApprovalAction;
        }
        public Date getCreatedDate() {
            return createdDate;
        }
        public void setCreatedDate(Date createdDate) {
            this.createdDate = createdDate;
        }
        public Date getModifiedDate() {
            return modifiedDate;
        }
        public void setModifiedDate(Date modifiedDate) {
            this.modifiedDate = modifiedDate;
        }
        public String getStatusName() {
            return statusName;
        }
        public void setStatusName(String statusName) {
            this.statusName = statusName;
        }
        public String getModifiedBy() {
            return modifiedBy;
        }
        public void setModifiedBy(String modifiedBy) {
            this.modifiedBy = modifiedBy;
        }

}

