package model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "visitor_type")
public class VisitorType {
	@Id
	@Column(name="visitor_type_id")
	private int visitorTypeId;
	@Column(name="visitor_type_name")
	private String visitorType;

	/*@OneToOne(mappedBy = "visitorType")
	private VisitorDetails visitorDetails;

	public VisitorDetails getVisitorDetails()
	{
		return visitorDetails;
	}

	public void setVisitorDetails(VisitorDetails visitorDetails)
	{
		this.visitorDetails = visitorDetails;
	}*/

	public int getVisitorTypeId() {
		return visitorTypeId;
	}

	public void setVisitorTypeId(int visitorTypeId) {
		this.visitorTypeId = visitorTypeId;
	}

	public String getVisitorType() {
		return visitorType;
	}

	public void setVisitorType(String visitorType) {
		this.visitorType = visitorType;
	}

	public VisitorType() {
	}

	@Override
	public String toString() {
		return "VisitorType{" +
				"visitorTypeId=" + visitorTypeId +
				", visitorType='" + visitorType + '\'' +
				/*", visitorDetails=" + visitorDetails +*/
				'}';
	}
}
