package dao;
import model.Department;
import model.JsonOutput;
import model.Location;
import model.Reason;
import model.Status;
import model.VisitorDetails;
import model.VisitorInfo;
import model.VisitorType;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
@Repository
public class VisitorDaoImpl implements VisitorDao
{
    final static Logger log = Logger.getLogger(VisitorDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public List<VisitorDetails> getManagerview()
	{
		List<VisitorDetails> managerList = null;
		try
		{
			Session currentSession = sessionFactory.getCurrentSession();
			Query<VisitorDetails> query = currentSession.createQuery(" from VisitorDetails ");
			managerList = query.getResultList();
			log.info("manager view" +managerList);
			if(managerList!=null && !managerList.isEmpty())
			{
				return managerList;
			}
			else
			{
				log.info("there is no details");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return managerList;
	}
	@Override
	public boolean updateById(VisitorDetails visitorDetails)
	{
		boolean status = false;
		try
		{
			sessionFactory.getCurrentSession().update(visitorDetails);
			status = true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return status;
	}
	@Override
	public boolean saveVisitor(VisitorDetails visitorDetails) {
		boolean status = false;
		if(!status){

		}

			sessionFactory.getCurrentSession().save(visitorDetails);
			status = true;

				return status;


	}
	@Override
	//public Map<Integer,String> getVisitorTypeNames()
	public List<JsonOutput> getVisitorTypeNames()
	{
		Map<Integer, String> visitorTypeMap = new HashMap<>();
		List<JsonOutput> visitorTypeList = new ArrayList<>();
		Session currentSession = sessionFactory.getCurrentSession();
		Query<VisitorType> query = currentSession.createQuery("from VisitorType");
		List<VisitorType> visitortypes = query.list();
		for (VisitorType visitortype : visitortypes)
		{
			visitorTypeMap.put(visitortype.getVisitorTypeId(), visitortype.getVisitorType());
			JsonOutput json = new JsonOutput();
			json.setKey(visitortype.getVisitorTypeId());
			json.setValue(visitortype.getVisitorType());
			visitorTypeList.add(json);
		}
		return visitorTypeList;
	}
	@Override
	//public Map<Integer,String> getReasonNames()
	public List<JsonOutput> getReasonNames()
	{
		Map<Integer, String> reasonMap = new HashMap<>();
		List<JsonOutput> reasonList = new ArrayList<>();
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Reason> query = currentSession.createQuery("from Reason");
		List<Reason> reasons = query.list();
		for (Reason reason : reasons)
		{
			reasonMap.put(reason.getReasonId(), reason.getReasonName());
			JsonOutput json = new JsonOutput();
			json.setKey(reason.getReasonId());
			json.setValue(reason.getReasonName());
			reasonList.add(json);
		}
		return reasonList;
	}
	@Override
	//public Map<Integer,String> getDeptNames()
	public List<JsonOutput> getDeptNames()
	{
		Map<Integer, String> deptmap = new HashMap<>();
		List<JsonOutput> deptList = new ArrayList<>();
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Department> query = currentSession.createQuery("from Department");
		List<Department> departments = query.list();
		for (Department department : departments)
		{
			deptmap.put(department.getDeptId(), department.getDeptName());
			JsonOutput json = new JsonOutput();
			json.setKey(department.getDeptId());
			json.setValue(department.getDeptName());
			deptList.add(json);
		}
		return deptList;
	}
	@Override
	//public Map<Integer,String> getLocNames()
	public List<JsonOutput> getLocNames()
	{
		Map<Integer, String> locationMap = new HashMap<>();
		List<JsonOutput> locationList = new ArrayList<>();
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Location> query = currentSession.createQuery("from Location");
		List<Location> locations = query.list();
		for (Location location : locations)
		{
			locationMap.put(location.getLocationId(), location.getLocationName());
			JsonOutput json = new JsonOutput();
			json.setKey(location.getLocationId());
			json.setValue(location.getLocationName());
			locationList.add(json);
		}
		return locationList;
	}
	public List<JsonOutput> getStatusName()
	{
		Map<Integer, String> statusMap = new HashMap<>();
		List<JsonOutput> statusList = new ArrayList<>();
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Status> query = currentSession.createQuery("from Status");
		List<Status> statuses = query.list();
		for (Status status : statuses)
		{
			statusMap.put(status.getStatusId(), status.getStatusName());
			JsonOutput json = new JsonOutput();
			json.setValue(status.getStatusName());
			statusList.add(json);
		}
		return statusList;
	}
	@Override
	public List<VisitorInfo> getManagerview1()
	{
		Session currentSession = sessionFactory.getCurrentSession();
		Query query = currentSession.createQuery("from VisitorDetails");
		List<VisitorInfo> list = query.getResultList();
		System.out.println("manager"+list);
		return list;
	}
	@Override
	public List<VisitorInfo> getSelectedVisitorList(Set<Integer> visitorIdList)
	{
		Session currentSession =sessionFactory.getCurrentSession();
		Query query = currentSession.createQuery( "select v.visitorId,v.visitorName, l.locationName,r.reasonName,v.visitorEmailId,vt.visitorType,v.createdDate,"
				+ "v.additionMaterial,v.approverComments,v.visitorApprovalAction,d.deptName,v.authorizedEscort,v.modifiedBy,"
				+ " v.modifiedDate,v.accessReqFrom,v.accessReqTill from VisitorDetails v"
				+ " left join Location l on l.locationId = v.locationId"
				+ " left join Reason r on r.reasonId = v.reasonId"
				+ " left join VisitorType vt on vt.visitorTypeId=v.visitorTypeId "
				+ " left join Department d on d.deptId =v.deptId"
				+ " where visitor_id IN (:visitorList)");
		query.setParameterList("visitorList", visitorIdList);
		List<Object[]> res = query.getResultList();
		List<VisitorInfo> visitorDetailsList = new ArrayList<VisitorInfo>();
		Iterator it = res.iterator();
		while(it.hasNext()){
			Object[] line = (Object[]) it.next();
			VisitorInfo v1 = new VisitorInfo();
			v1.setVisitorId((int) line[0]);
			v1.setVisitorName((String)line[1]);
			v1.setLocationName((String)line[2]);
			v1.setReasonName((String)line[3]);
			v1.setVisitorEmailId((String)line[4]);
			v1.setVisitorType((String)line[5]);
			v1.setCreatedDate((Date)line[6]);
			v1.setAdditionMaterial((String)line[7]);
			v1.setApproverComments((String)line[8]);
			v1.setVisitorApprovalAction((String)line[9]);
			v1.setDeptName((String)line[10]);
			v1.setAuthorizedEscort((String)line[11]);
			v1.setModifiedBy((String)line[12]);
			v1.setModifiedDate((Date)line[13]);
			v1.setAccessReqFrom((Date)line[14]);
			v1.setAccessReqTill((Date)line[15]);
			visitorDetailsList.add(v1);
		}
		return visitorDetailsList;
	}

}


