package configuration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.apache.log4j.Logger;

@SpringBootApplication
public class VisitorAccessApplication
{
	static Logger log = Logger.getLogger(VisitorAccessApplication.class);
	public static void main(String[] args)
	{
		log.info("logger");
		SpringApplication.run(VisitorAccessApplication.class, args);

	}
}
