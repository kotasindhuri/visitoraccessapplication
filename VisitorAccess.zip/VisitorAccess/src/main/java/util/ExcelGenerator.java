package util;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import model.VisitorInfo;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelGenerator {
public static String loadDataToExcel(List<VisitorInfo> managerList) {
		
		String[] columns = {"Visitor Id", "Visitor Name", "Location Name", "Reason Name", "E-Mail", "Visitor Type", "Created Date", "Additional Materials", "Approver Comments", "Visitor Approval Action", "Department Name", "Authorized Escort", "Modified By", "Modified Date", "Access Request From", "Access Request Till", "Status Name", "Modified Status"};
		
		 Workbook workbook = new XSSFWorkbook();
		
		 
		 Sheet sheet = workbook.createSheet("VisitorDetails");
		 
		 Font headerFont = workbook.createFont();
	        headerFont.setBold(true);
	        headerFont.setFontHeightInPoints((short) 14);
	        headerFont.setColor(IndexedColors.BLUE.getIndex());
	        CellStyle headerCellStyle = workbook.createCellStyle();
	        headerCellStyle.setFont(headerFont);
	        
	        Row headerRow = sheet.createRow(0);
	        
	        for(int i = 0; i < columns.length; i++) {
	            Cell cell = headerRow.createCell(i);
	            cell.setCellValue(columns[i]);
	            cell.setCellStyle(headerCellStyle);
	        }
	        // data
	       
	            
	            int rowNum = 1;
	            for(VisitorInfo visitordetails: managerList) {
	                Row row = sheet.createRow(rowNum++);

	                row.createCell(0)
	                        .setCellValue(visitordetails.getVisitorId());

	                row.createCell(1)
	                        .setCellValue(visitordetails.getVisitorName());

	                row.createCell(2)
	                        .setCellValue(visitordetails.getLocationName());
	                
	                row.createCell(3)
                    .setCellValue(visitordetails.getReasonName());
	                
	                row.createCell(4)
	                .setCellValue(visitordetails.getVisitorEmailId());
	                
	                row.createCell(6)
	                .setCellValue(visitordetails.getCreatedDate());
	                
	                row.createCell(7)
	                .setCellValue(visitordetails.getAdditionMaterial());
	                
	                row.createCell(8)
	                .setCellValue(visitordetails.getApproverComments());
	                
	                row.createCell(9)
	                .setCellValue(visitordetails.getVisitorApprovalAction());
	                
	                row.createCell(10)
	                .setCellValue(visitordetails.getDeptName());
	                
	                row.createCell(11)
	                .setCellValue(visitordetails.getAuthorizedEscort());

	                row.createCell(12)
	                .setCellValue(visitordetails.getModifiedBy());
	                
	                row.createCell(13)
	                .setCellValue(visitordetails.getModifiedDate());
	                
	                row.createCell(14)
	                .setCellValue(visitordetails.getAccessReqFrom());
	                
	                row.createCell(15)
	                .setCellValue(visitordetails.getAccessReqTill());
	            }
	    		// Resize all columns to fit the content size
	            for(int i = 0; i < columns.length; i++) {
	                sheet.autoSizeColumn(i);
	            }

	            // Write the output to a file
	            FileOutputStream fileOut;
				try {
					fileOut = new FileOutputStream("visitor-file.xlsx");
					workbook.write(fileOut);
		            fileOut.close();

		            // Closing the workbook
		            workbook.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		return "excelLoaded";
	}

}
