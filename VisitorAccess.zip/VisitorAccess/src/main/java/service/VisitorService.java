package service;
import model.JsonOutput;
import model.VisitorDetails;
import model.VisitorInfo;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;
public interface VisitorService
{
	public boolean saveVisitor(VisitorDetails visitorDetails);
	public List<VisitorDetails> getManagerview();
	public boolean updateById(VisitorDetails visitorDetails);
	public List<JsonOutput> getDeptNames();
	public List<JsonOutput> getVisitorTypeNames();
	public List<JsonOutput> getReasonNames();
	public List<JsonOutput> getLocNames();
	public List<JsonOutput> getStatusName();
    public List<VisitorInfo> getManagerview1();
	public List<VisitorInfo> getSelectedVisitorList(Set<Integer> ids);
}

