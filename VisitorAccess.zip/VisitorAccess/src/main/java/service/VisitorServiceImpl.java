package service;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import model.JsonOutput;
import model.VisitorDetails;
import model.VisitorInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import dao.VisitorDao;
@Service
@Transactional
public class VisitorServiceImpl implements VisitorService
{
	@Autowired
	private VisitorDao visitorDao;
	@Override
	public boolean saveVisitor(VisitorDetails visitorDetails)
	{
		return visitorDao.saveVisitor(visitorDetails);
	}
	@Override
	public List<VisitorDetails> getManagerview()

	{
		return visitorDao.getManagerview();
	}
	@Override
    public boolean updateById(VisitorDetails visitorDetails)
	{
		return visitorDao.updateById(visitorDetails);
	}
	@Override
	//public Map<Integer, String> getLocNames()
	public List<JsonOutput> getLocNames()
	{
		return visitorDao.getLocNames();
	}
	@Override
	//public Map<Integer,String> getDeptNames()
	public List<JsonOutput> getDeptNames()
	{
		return visitorDao.getDeptNames();
	}
	@Override
	//public Map<Integer,String> getVisitorTypeNames()
	public List<JsonOutput> getVisitorTypeNames()
	{
		return visitorDao.getVisitorTypeNames();
	}
	@Override
	//public Map<Integer, String> getReasonNames()
	public List<JsonOutput> getReasonNames()
	{
		return visitorDao.getReasonNames();
	}

	public List<JsonOutput> getStatusName()
	{
		return visitorDao.getStatusName();
	}
	@Override
	public List<VisitorInfo> getManagerview1()
	{
		return visitorDao.getManagerview1();
	}
	@Override
	public List<VisitorInfo> getSelectedVisitorList(Set<Integer> ids)
	{
		return visitorDao.getSelectedVisitorList(ids);
	}
}

