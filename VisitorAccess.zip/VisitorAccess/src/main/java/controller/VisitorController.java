package controller;
import model.JsonOutput;
import model.VisitorDetails;
import model.VisitorInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import service.VisitorService;
import util.ExcelGenerator;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;
@RestController
@CrossOrigin(origins="http://localhost:4200")
/*@RequestMapping(value="/api")*/
public class VisitorController
{
	@Autowired
	private VisitorService visitorservice;
	@PostMapping(path = "/save-visitor", consumes = "application/json")
	public boolean saveVisitor(@RequestBody VisitorDetails visitorDetails)
	{
		return visitorservice.saveVisitor(visitorDetails);
	}
	@GetMapping("managerlist")
	public List<VisitorDetails> getManagerview()
	{
		return visitorservice.getManagerview();
	}
    @PutMapping("/edit/{visitor_id}")
    public boolean updateById(@RequestBody VisitorDetails visitorDetails, @PathVariable("visitor_id") int visitor_id)
    {
			visitorDetails.setVisitorId(visitor_id);
			return visitorservice.updateById(visitorDetails);
    }
	@GetMapping("/dept_list")
	//public Map<Integer,String> getDeptNames()
	public List<JsonOutput> getDeptNames()
	{
		return visitorservice.getDeptNames();
	}
	@GetMapping("/loc_list")
	//public Map<Integer,String> getLocNames()
	public List<JsonOutput> getLocNames()
	{
		return visitorservice.getLocNames();
	}
	@GetMapping("/vistype_list")
	//public Map<Integer,String> getVisitorTypeNames()
	public List<JsonOutput> getVisitorTypeNames()
	{
		return visitorservice.getVisitorTypeNames();
	}
    @GetMapping("/reasons_list")
    //public Map<Integer,String> getReasonNames()
	public List<JsonOutput> getReasonNames()
    {
        return visitorservice.getReasonNames();
    }
	@GetMapping("/status_list")
	//public Map<Integer,String> getStatusName()
	public List<JsonOutput> getStatusName()
	{
		return visitorservice.getStatusName();
	}
	@GetMapping("/generateExcel")
	public String exportVisitorData()
	{
		List<VisitorInfo> managerList = visitorservice.getManagerview1();
		return ExcelGenerator.loadDataToExcel(managerList);
	}
	@GetMapping("/generate")
	public String getvisitorIds(@RequestParam(value="id") Set<Integer> ids)
	{
		List<VisitorInfo> visitorList =visitorservice.getSelectedVisitorList(ids);
		System.out.println(visitorList);
		return ExcelGenerator.loadDataToExcel(visitorList);
	}
}


